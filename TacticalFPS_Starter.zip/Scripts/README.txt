TACTICAL FPS (Unity 2022 LTS+/URP) — วิธีติดตั้ง
1. Project 3D (URP) + ติดตั้ง TextMeshPro. Player Settings > Active Input Handling = Both
2. ใส่ Scripts ทั้งหมดใน Assets/Scripts
3. Player: CharacterController + PlayerController + WeaponController + Health, ลูก: Camera
   Collider ย่อย Head/Body/Leg ใส่ HitZone (layer ไม่ใช่ layer ผู้เล่นตัวเอง)
4. Create > Tactical > Weapon สร้าง 8 อาวุธ (ดูตารางใน WeaponData.cs)
5. Scene "Match": GameManager (ใส่ players + spawn), Canvas+HUD, SpikeSite 2 จุด (BoxCollider isTrigger)
6. 5v5/2v2/1v1: ปรับจำนวน players ตาม MainMenu.mode (บอทเติมที่ว่าง)
7. ออนไลน์/สร้างห้อง: ใช้ Netcode for GameObjects + Unity Relay/Lobby (หรือ Photon Fusion)
   แยก Server-authoritative: ยิง/ดาเมจ/เงิน/รอบ ให้ server คำนวณ
